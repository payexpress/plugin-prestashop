/**
 * Created by PhpStorm.
 * User: PAPE SAMBA NDOUR : 777293282; papesambandour@hotmail.com
 * Date: 05/04/2018
 * Time: 13:09
 */
$(document).ready(function() {
    $('.page-order-confirmation #order-details ul').append($('#payexpresse_transaction_id'));
});